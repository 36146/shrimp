#include "motor.h"


void Pwm_Init(void)
{
	HAL_TIM_PWM_Start(&htim12,TIM_CHANNEL_1); //MOTORA
	HAL_TIM_PWM_Start(&htim12,TIM_CHANNEL_2); //MOTORA
	
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_4);  //MOROTB
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_3);  //MOTORB
	
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);  //MOTORC
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);  //MOROTC
	
	HAL_TIM_PWM_Start(&htim13,TIM_CHANNEL_1); //MOTORD
	HAL_TIM_PWM_Start(&htim14,TIM_CHANNEL_1); //MOTORD
 }

void Pwm_Set(int MotorA,int MotorB,int MotorC,int MotorD)
{
	__HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_1,MotorA);
	__HAL_TIM_SetCompare(&htim8,TIM_CHANNEL_3,MotorB);
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,MotorC);
	__HAL_TIM_SetCompare(&htim13,TIM_CHANNEL_1,MotorD);
	
}