#include "sensor.h"

uint32_t turr_value;
uint32_t ph_value;



uint32_t Get_ADC_Value(ADC_HandleTypeDef *hadc)
{
    uint32_t adc_value = 0;
		HAL_ADC_Start(hadc);
    adc_value = HAL_ADC_GetValue(hadc);

    return adc_value;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM10)
	{
		ph_value=Get_ADC_Value(&hadc1);
		turr_value=Get_ADC_Value(&hadc2);
		ph_value=Get_ADC_Value(&hadc3);
	}
}


