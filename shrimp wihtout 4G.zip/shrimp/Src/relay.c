#include "relay.h"

#define relay GPIOD
#define water_pin GPIO_PIN_9
#define light_pin GPIO_PIN_8
#define oxygen_pin GPIO_PIN_10

void relay_control(int water,int light,int oxygen)
{
	if(water==1)
	{
		HAL_GPIO_WritePin(relay,water_pin,GPIO_PIN_RESET);
	}else
	{
		HAL_GPIO_WritePin(relay,water_pin,GPIO_PIN_SET);
	}
	if(light==1)
	{
		HAL_GPIO_WritePin(relay,light_pin,GPIO_PIN_RESET);
	}else
	{
		HAL_GPIO_WritePin(relay,light_pin,GPIO_PIN_SET);
	}
	if(oxygen==1)
	{
		HAL_GPIO_WritePin(relay,oxygen_pin,GPIO_PIN_RESET);
	}else
	{
		HAL_GPIO_WritePin(relay,oxygen_pin,GPIO_PIN_SET);
	}
}