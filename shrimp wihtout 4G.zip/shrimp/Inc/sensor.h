#ifndef __SENSOR_H
#define __SENSOR_H

#include "stm32f4xx.h"                  // Device header
#include "adc.h"

#endif
