#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f4xx.h"                  // Device header
#include "tim.h"

void Pwm_Set(int motorA,int motorB,int MotorC,int MotorD);
void Pwm_Init(void);

#endif
