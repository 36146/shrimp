#ifndef __RELAY_H
#define __RELAY_H

#include "stm32f4xx.h"                  // Device header
void relay_control(int water,int light,int oxygen);


#endif
